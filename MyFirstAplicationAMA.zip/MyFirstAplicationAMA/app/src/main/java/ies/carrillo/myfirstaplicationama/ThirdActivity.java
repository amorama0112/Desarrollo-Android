package ies.carrillo.myfirstaplicationama;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ThirdActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnVolver;
    TextView nombre;
    TextView numero;
    TextView numeroDec;
    TextView booleano;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_third);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent viewMainIntent = getIntent();
        btnVolver = (Button) findViewById(R.id.volver);
        nombre = (TextView) findViewById(R.id.nombreMsg);
        numero = (TextView) findViewById(R.id.numeroMsg);
        numeroDec = (TextView) findViewById(R.id.numeroDecMsg);
        booleano = (TextView) findViewById(R.id.booleanoMsg);

        nombre.setText(viewMainIntent.getStringExtra("name"));
        nombre.setTextColor(Color.BLACK);
        if (nombre.getText().toString().isEmpty()) {
            nombre.setText("No se ha especificado nombre");
            nombre.setTextColor(Color.RED);
        }


        numero.setText(viewMainIntent.getStringExtra("number"));
        numero.setTextColor(Color.BLACK);
        if (numero.getText().toString().isEmpty()) {
            numero.setText("No se ha especificado numero");
            numero.setTextColor(Color.RED);
        }


        numeroDec.setText(viewMainIntent.getStringExtra("numberDec"));
        numeroDec.setTextColor(Color.BLACK);
        if (numeroDec.getText().toString().isEmpty()) {
            numeroDec.setText("No se ha especificado numero decimal");
            numeroDec.setTextColor(Color.RED);
        }


        booleano.setText(viewMainIntent.getStringExtra("boolean"));
        booleano.setTextColor(Color.BLACK);


        btnVolver.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(btnVolver.isPressed()) {
            Intent viewNameIntent = new Intent(this, MainActivity.class);

            startActivity(viewNameIntent);
        }
    }
}