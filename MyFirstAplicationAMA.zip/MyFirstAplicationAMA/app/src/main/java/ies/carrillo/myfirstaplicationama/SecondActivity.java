package ies.carrillo.myfirstaplicationama;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnEnviar;
    EditText nombre;
    EditText numero;
    EditText numeroDecimal;

    SwitchCompat booleano;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnEnviar = (Button) findViewById(R.id.enviar);
        nombre = (EditText) findViewById(R.id.nombre);
        numero = (EditText) findViewById(R.id.numero);
        numeroDecimal = (EditText) findViewById(R.id.numeroDecimal);
        booleano = (SwitchCompat) findViewById(R.id.switch1);

        btnEnviar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(btnEnviar.isPressed()) {
            Intent viewNameIntent = new Intent(this, ThirdActivity.class);

            viewNameIntent.putExtra("name", nombre.getText().toString());
            viewNameIntent.putExtra("number", numero.getText().toString());
            viewNameIntent.putExtra("numberDec", numeroDecimal.getText().toString());
            viewNameIntent.putExtra("boolean", booleano.isChecked());

            startActivity(viewNameIntent);
        }
    }
}